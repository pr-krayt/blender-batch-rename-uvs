import bpy

class OBJECT_OT_batch_rename_uv(bpy.types.Operator):
    """Rename UV maps for all selected objects"""
    bl_idname = "object.batch_rename_uv"
    bl_label = "Rename UVs"
    bl_options = {'REGISTER', 'UNDO'}

    # Add a toggle for the mode
    use_active_only: bpy.props.BoolProperty(
        name="Rename Active UV Only",
        default=True,
        description="Rename the active UV map regardless of its current name"
    )
    old_name: bpy.props.StringProperty(name="Target Name", default="UVMap")
    new_name: bpy.props.StringProperty(name="New Name", default="UV_Base")

    def execute(self, context):
        count = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                if self.use_active_only:
                    # Rename whatever is currently selected in the UI
                    if obj.data.uv_layers.active:
                        obj.data.uv_layers.active.name = self.new_name
                        count += 1
                else:
                    # Search for a specific name
                    uv_map = obj.data.uv_layers.get(self.old_name)
                    if uv_map:
                        uv_map.name = self.new_name
                        count += 1
        
        self.report({'INFO'}, f"Renamed UV maps on {count} objects")
        return {'FINISHED'}

class VIEW3D_PT_batch_rename_uv_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Edit'
    bl_label = "Batch Rename UVs"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        layout.operator("object.batch_rename_uv", text="Rename UVs")

def register():
    bpy.utils.register_class(OBJECT_OT_batch_rename_uv)
    bpy.utils.register_class(VIEW3D_PT_batch_rename_uv_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_batch_rename_uv)
    bpy.utils.unregister_class(VIEW3D_PT_batch_rename_uv_panel)

if __name__ == "__main__":
    register()